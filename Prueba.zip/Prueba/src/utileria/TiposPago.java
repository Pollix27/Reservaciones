package utileria;

public enum TiposPago {
    EFECTIVO,
    CREDITO,
    DEBITO,
    CHEQUE;
}
