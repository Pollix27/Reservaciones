package utileria;

public enum EstadoReservacion {
     SOLICITADA, CONFIRMADA, PAGADA, CANCELADA, ERROR;
}