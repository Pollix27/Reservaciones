import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import modelo.Habitacion;
import modelo.Hotel;
import modelo.Huesped;

public class App {
    public static void main(String[] args) throws Exception {
        // Crear habitaciones
        List<Habitacion> habitaciones = new ArrayList<>();
        habitaciones.add(new Habitacion(101, 2, 500f));
        habitaciones.add(new Habitacion(102, 3, 750f));

        // Crear hotel
        Hotel hotel = new Hotel(habitaciones);

        // Crear huésped y agregar al hotel
        Huesped h = new Huesped("Juan Perez", 5512345678L, "juan@example.com");
        hotel.agregarHuesped(h);

        // Buscar disponibilidad para 2 personas
        List<Habitacion> disponibles = hotel.buscarDisponibilidad(LocalDate.now(), LocalDate.now().plusDays(2), 2);
        if(disponibles.isEmpty()){
            System.out.println("No hay habitaciones disponibles");
            return;
        }

        // Reservar la primera disponible por 2 noches
        List<Habitacion> seleccion = new ArrayList<>();
        seleccion.add(disponibles.get(0));
        hotel.generarReservacion(h, seleccion, LocalDate.now(), 2);

        System.out.println("Reservación creada para: " + h.getNombre());
        System.out.println("Habitación reservada: " + seleccion.get(0).getNumero());
        System.out.println("Estado de la habitación (ocupado): " + seleccion.get(0).isOcupado());
    }
}
