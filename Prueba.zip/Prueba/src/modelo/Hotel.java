package modelo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import utileria.EstadoReservacion;

public class Hotel {
    private List<Huesped> listaHuespedes;
    private List<Habitacion> habitaciones;
    private List<Reservacion> listaReservaciones;
    
    public Hotel(List<Habitacion> habitaciones) {
        this.habitaciones = habitaciones;
        this.listaHuespedes = new ArrayList<>();
        this.listaReservaciones = new ArrayList<>();
    }
    
    public List<Huesped> getListaHuespedes() {
        return listaHuespedes;
    }
    public void setListaHuespedes(List<Huesped> listaHuespedes) {
        this.listaHuespedes = listaHuespedes;
    }

    // Busca un huésped por CURP o correo si está disponible
    public Huesped buscarHuesped(Huesped h){
       if(h == null) return null;
       for(Huesped x : listaHuespedes){
           if(x.getCURP() != null && x.getCURP().equals(h.getCURP())) return x;
           if(x.getCorreo() != null && x.getCorreo().equals(h.getCorreo())) return x;
       }
       return null;
    }

    public void agregarHuesped(Huesped h){
        if(h == null) return;
        if(this.listaHuespedes == null) this.listaHuespedes = new ArrayList<>();
        this.listaHuespedes.add(h);
    }

    // Genera una reservación sencilla: marca habitaciones ocupadas y la agrega a la lista
    public void generarReservacion(Huesped h,List<Habitacion> cuartos,LocalDate fe, int noches){
        if(h==null || cuartos==null || cuartos.isEmpty()) return;
        Reservacion r = new Reservacion(h, cuartos, 0, fe, fe.plusDays(noches));
        r.setEstado(EstadoReservacion.SOLICITADA);
        this.listaReservaciones.add(r);
        for(Habitacion hab : cuartos){
            hab.setOcupado(true);
        }
    }

    // Busca habitaciones disponibles ignorando conflictos por fecha (simplificado)
    public List<Habitacion> buscarDisponibilidad(LocalDate fe, LocalDate fs, int np){
        List<Habitacion> disponibles = new ArrayList<>();
        for(Habitacion h : habitaciones){
            if(!h.isOcupado() && h.getCapacidad() >= np){
                disponibles.add(h);
            }
        }
        return disponibles;
    }

    private void actualizarReservacion(Reservacion r,EstadoReservacion ne){
        if(r==null) return;
        r.setEstado(ne);
    }

    public void cancelarReservacion(Reservacion r){
        if(r==null) return;
        r.setEstado(EstadoReservacion.CANCELADA);
        for(Habitacion hab : r.getHabitaciones()){
            hab.setOcupado(false);
        }
    }

    public Reservacion buscarReservacion(Huesped h,LocalDate fechaEntrada){
        if(h==null) return null;
        for(Reservacion r : listaReservaciones){
            if(r.getHuesped()!=null && r.getHuesped().getCorreo()!=null && h.getCorreo()!=null
                    && r.getHuesped().getCorreo().equals(h.getCorreo())
                    && r.getFechaEntrada()!=null && r.getFechaEntrada().equals(fechaEntrada)){
                return r;
            }
        }
        return null;
    }
    
    public void checkIn(Reservacion r){
        if(r==null) return;
        r.setEstado(EstadoReservacion.PAGADA);
    }
    public void chechOut(Reservacion r){
        if(r==null) return;
        for(Habitacion h : r.getHabitaciones()){
            h.setOcupado(false);
        }
        r.setEstado(EstadoReservacion.CANCELADA);
    }

}
